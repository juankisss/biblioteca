<div class="row">
    <div class="form-group col-sm-6">
        <label>Nombre</label>
        <input type="text" name="EDI_NOMBRE" class="form-control EDI_NOMBRE" required>
    </div>
    <div class="form-group col-sm-6">
        <label>Teléfono</label>
        <input type="text" name="EDI_TELEFONOS" class="form-control EDI_TELEFONOS">
    </div>
</div>
<div class="row">
    <div class="form-group col-sm-6">
        <label>País</label>
        <input type="text" name="EDI_PAIS" class="form-control EDI_PAIS">
    </div>
    <div class="form-group col-sm-6">
        <label>Ciudad</label>
        <input type="text" name="EDI_CIUDAD" class="form-control EDI_CIUDAD">
    </div>
</div>
<div class="row">
    <div class="form-group col-sm-12">
        <label>Dirección</label>
        <textarea type="text" name="EDI_DIRECCION" class="form-control EDI_DIRECCION"></textarea>
    </div>
</div><?php /**PATH C:\xampp\htdocs\sis_biblioteca\resources\views/editoriales/form.blade.php ENDPATH**/ ?>