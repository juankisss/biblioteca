
<?php $__env->startSection('contenido'); ?>
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <?php echo $__env->make('partials.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
                <div class="col-lg-12">
                    <!-- USER DATA-->
                    <div class="user-data m-b-30">
                        <h3 class="title-3 m-b-30">
                            <i class="zmdi zmdi-account-calendar"></i>Administración de Reservas<button class="pull-right au-btn au-btn-icon au-btn--blue au-btn--small bg-dark" data-toggle="modal" data-target="#fModal"><i class="zmdi zmdi-plus"></i>Nueva Reserva</button></h3>
                        <hr>
                        <div class="table-responsive content">
                            <table class="table tabla-datos table-hover table-responsive table-bordered list" id="table1"  data-get="<?php echo e(url('/reservas')); ?>">
                                <thead class="">
                                    <tr>
                                        <th width="3%">ID</th>
                                        <th>Ejemplar</th>
                                        <th>Lector</th>
                                        <th>Fecha</th>
                                        <th>Reserva</th>
                                        <th>Observaciones</th>
                                        <th>Estado</th>
                                        <th width="4%"></th>
                                        <!--<th width="4%"></th>-->
                                        <th width="4%"></th>
                                    </tr>
                                </thead>
                                <tbody id="itemContainer">
                                    <?php $c=1 ?>
                                    <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php //date_default_timezone_set('America/La_Paz');
                                    	$sop = '';
                                        if($s->RES_ESTADO==2){
                                        	$sop = 'alert-success';
                                        }if($s->RES_ESTADO==3){
                                        	$sop = 'alert-warning';
                                        }if($s->RES_ESTADO==1){
                                        	if($s->RES_FECHAR<date("Y-m-d")){ 
                                            	$sop = 'alert-danger'; 
                                            }else{
                                            	$sop = 'alert-info';
                                            }
                                        }  
                                    ?>
                                    <tr class="<?php echo e($sop); ?>">
                                        <td><?php echo e($c++); ?></td>
                                        <td><?php echo e($s->CON_TITULO); ?></td>
                                        <td><?php echo e($s->USL_ID); ?> (<?php echo e($s->LET_NOMBRE); ?>)</td>
                                        <td><?php echo e($s->RES_FECHA); ?></td>
                                        <td><?php echo e($s->RES_FECHAR." ".$s->RES_HORAR); ?></td>
                                        <td><?php echo e($s->RES_OBS); ?></td>
                                            <?php if($s->RES_ESTADO == 1): ?>
                                                <td>Programada</td>
                                            <?php elseif($s->RES_ESTADO == 2): ?>
                                                <td>Concretada</td>
                                            <?php else: ?>
                                                <td>Cancelada</td>
                                            <?php endif; ?>
                                        <td class="text-center"><?php if($s->RES_ESTADO==1): ?><a href="#" class="btn btn-primary" data-toggle="modal" data-target="#RegModal" title="Registrar Prestamo" onClick="modificar('<?php echo e($s->RES_ID); ?>'),reservas('<?php echo e($s->RES_ID); ?>','<?php echo e($s->EJE_ID); ?>')"><i class="fa fa-upload"></i></a><?php endif; ?></td>
                                        <!--<td class="text-center"><?php if($s->RES_ESTADO==1): ?><a href="#" class="btn btn-success" data-toggle="modal" data-target="#EditModal" title="Modificar" onClick="modificar('<?php echo e($s->RES_ID); ?>')"><i class="fa fa-edit"></i></a><?php endif; ?></td>-->
                                        <td class="text-center"><?php if($s->RES_ESTADO==1): ?><a href="#" class="btn btn-danger" title="Borrar" onClick="eliminar('<?php echo e($s->RES_ID); ?>', '<?php echo e($s->USP_ID); ?>')"><i class="fa fa-trash"></i></a><?php endif; ?>
                                        <form action="<?php echo e(route('reservas.destroy', $s->RES_ID)); ?>" method="post" class="form-delete<?php echo e($s->RES_ID); ?>">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                        </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- END USER DATA-->
                </div>                
            </div> 
            <div class="row">
                <div class="col-md-12">
                    <div class="copyright">
                        <p>Copyright © 2022</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
            </div>
<?php echo $__env->make('reservas.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('reservas.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('reservas.reg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis_biblioteca\resources\views/reservas/list.blade.php ENDPATH**/ ?>