    
    <div class="row">
        <div class="form-group col-sm-12">
            <label>Nombre</label>
            <input type="text" name="LET_NOMBRE" class="form-control LET_NOMBRE" required readonly>
        </div>
    </div>

    <div class="row">
        <div class="form-group col-sm-12">
            <label>Detalle</label>
            <textarea name="LET_DETALLE" class="form-control LET_DETALLE"></textarea>
        </div>
    </div>
    
    <div class="row">
        <div class="form-group col-sm-12">
            <label>Tiempo (Dias)</label>
            <input type="number" name="LET_TIEMPOM" class="form-control LET_TIEMPOM" required>
        </div>
    </div>
<?php /**PATH D:\xampp8\htdocs\sis_biblioteca\resources\views/tipol/form.blade.php ENDPATH**/ ?>