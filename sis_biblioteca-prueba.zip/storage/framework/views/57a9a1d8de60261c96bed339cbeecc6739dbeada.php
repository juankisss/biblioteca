

<?php $__env->startSection('contenido'); ?>
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <?php echo $__env->make('partials.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
                <div class="col-lg-12">
                    <!-- USER DATA-->
                    <div class="user-data m-b-30">
                        <h3 class="title-3 m-b-30">
                            <i class="zmdi zmdi-account-calendar"></i>Administración de Personal<button class="pull-right au-btn au-btn-icon au-btn--blue au-btn--small" data-toggle="modal" data-target="#fModal"><i class="zmdi zmdi-plus"></i>Adicionar Personal</button></h3>
                        <hr>
                        <div class="table-responsive content">
                            <table class="table tabla-datos table-hover table-responsive table-bordered list" id="table1"  data-get="<?php echo e(url('/personal')); ?>">
                                <thead class="">
                                    <tr>
                                        <th width="3%">ID</th>
                                        <th>Nombre</th>
                                        <th>C.I.</th>
                                        <th>e-Mail</th>
                                        <th>Celular</th>
                                        <th>Dirección</th>
                                        <!--<th>Foto</th>
                                        <th>Cargo</th>-->
                                        <!--<th>Estado</th>-->
                                        <th width="4%"></th>
                                        <th width="4%"></th>
                                        <th width="4%"></th>
                                    </tr>
                                </thead>
                                <tbody id="itemContainer">
                                    <?php $c=1; ?>
                                    <?php $__currentLoopData = $personal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($c++); ?></td>
                                        <td><?php echo e($p->PER_NOMBRES.' '.$p->PER_APELLIDOS); ?></td>
                                        <td><?php echo e($p->PER_CI); ?></td>
                                        <td><?php echo e($p->PER_EMAIL); ?></td>
                                        <td><?php echo e($p->PER_CELULAR); ?></td>
                                        <!--<td><?php echo e($p->PER_DIRECCION); ?></td>
                                        <td><img src="<?php echo e(asset('fotos/personal_')); ?><?php echo e($p->PER_ID); ?>/<?php echo e($p->PER_FOTO); ?>" width="200"></td>-->
                                        <td><?php echo e($p->PER_DIRECCION); ?></td>
                                            <!--<?php if($p->PER_ESTADO == 1): ?>
                                                <td>Activo</td>
                                            <?php else: ?>
                                                <td>Inactivo</td>
                                            <?php endif; ?>-->
                                        <td class="text-center"><a href="#" class="btn btn-info" data-toggle="modal" data-target="#DetModal" title="detalle" onClick="detalle('<?php echo e($p->PER_ID); ?>')"><i class="fa fa-id-card"></i></a></td>
                                        <td class="text-center"><a href="#" class="btn btn-success" data-toggle="modal" data-target="#EditModal" title="Modificar" onClick="modificar('<?php echo e($p->PER_ID); ?>')"><i class="fa fa-edit"></i></a></td>
                                        <td class="text-center"><?php if(Session::get('pid')!=$p->PER_ID): ?><a href="#" class="btn btn-danger" title="Borrar" onClick="eliminar('<?php echo e($p->PER_ID); ?>', '<?php echo e($p->PER_NOMBRES." ".$p->PER_APELLIDOS); ?>')"><i class="fa fa-trash"></i></a>
                                        <form action="<?php echo e(route('personal.destroy', $p->PER_ID)); ?>" method="post" class="form-delete<?php echo e($p->PER_ID); ?>">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                        </form><?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- END USER DATA-->
                </div>                
            </div>           
            
            <div class="row">
                <div class="col-md-12">
                    <div class="copyright">
                        <p>Copyright © 2022</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
            </div>
<?php echo $__env->make('personal.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('personal.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('personal.det', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis_biblioteca\resources\views/personal/list.blade.php ENDPATH**/ ?>