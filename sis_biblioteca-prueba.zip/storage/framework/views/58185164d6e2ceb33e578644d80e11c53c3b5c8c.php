<div class="row">
    <div class="col-md-12">
        <div class="copyright">
            <p>Copyright © JC 2022</p>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\sis_biblioteca\resources\views/partials/footer-cont.blade.php ENDPATH**/ ?>