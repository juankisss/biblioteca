<?php if(Session::has('success')): ?>
	<div class="alert alert-success">
		<button type="button" class="close" data-dismiss="alert">&times;</button>
		<?php echo e(Session::get('success')); ?>

	</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\sis_biblioteca\resources\views/partials/success.blade.php ENDPATH**/ ?>