<div class="row">
    <div class="form-group col-sm-12">
        <label>Nombre</label>
        <input type="text" name="CAT_NOMBRE" class="form-control CAT_NOMBRE" required>
    </div>
</div>
<div class="row">
    <div class="form-group col-sm-12">
        <label>Descripción</label>
        <textarea type="text" name="CAT_DESC" class="form-control CAT_DESC"></textarea>
    </div>
</div>
<div class="row">
    <div class="form-group col-sm-12">
        <label>Resumen</label>
        <textarea type="text" name="CAT_RESUMEN" class="form-control CAT_RESUMEN"></textarea>
    </div>
</div>
<!--<div class="row">
    <div class="form-group col-sm-12">
        <label>Foto</label>
        <input type="file" name="file" class="form-control CAT_IMG">
    </div>
</div>--><?php /**PATH C:\xampp\htdocs\sis_biblioteca\resources\views/categorias/form.blade.php ENDPATH**/ ?>