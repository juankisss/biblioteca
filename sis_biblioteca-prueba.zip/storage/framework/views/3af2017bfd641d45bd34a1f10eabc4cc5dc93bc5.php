<?php if(Session::has('danger')): ?>
	<div class="alert alert-danger">
		<button type="button" class="close" data-dismiss="alert">&times;</button>
		<?php echo e(Session::get('danger')); ?>

	</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\sis_biblioteca\resources\views/partials/danger.blade.php ENDPATH**/ ?>