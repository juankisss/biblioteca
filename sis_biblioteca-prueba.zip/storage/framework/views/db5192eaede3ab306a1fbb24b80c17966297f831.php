

<?php $__env->startSection('contenido'); ?>
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <?php echo $__env->make('partials.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
                <div class="col-lg-12">
                    <!-- USER DATA-->
                    <div class="user-data m-b-30">
                        <h3 class="title-3 m-b-30">
                            <i class="zmdi zmdi-file"></i><?php echo e($title); ?><!--<button class="pull-right au-btn au-btn-icon btn-secondary au-btn--small"><i class="zmdi zmdi-print"></i>Actualizar Reporte</button>--></h3>
                        <hr>
                        <div class="table-responsive content">
                            <?php if($con=='personal'): ?>
                            	<?php $reporte = 'rep_'.$con; ?>
                            <?php elseif($con=='lectores'): ?>
                            <div class="row">
                            	<div class="form-group col-sm-6">
                                    <label>Genero</label>
                                    <select name="LEC_GENERO" id="genero" class="form-control" onChange="reportes('lectores')">
                                        <option value="-1">--Todos--</option>
                                        <option value="1">Masculino</option>
                                        <option value="2">Femenino</option>
                                    </select>
                                </div>
                                <div class="col-sm-6">
                                	<label>Tipo</label>
                                    <select name="LET_ID" id="tipol" class="form-control" onChange="reportes('lectores')">
                                        <option value="-1">--Todos--</option>
                                        <?php $__currentLoopData = $lectortipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($lt->LET_ID); ?>"><?php echo e($lt->LET_NOMBRE); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <?php $reporte = 'rep_'.$con.'/-1/-1'; ?>
                            <?php elseif($con=='contenidos'): ?>
                            <div class="row">
                                <div class="form-group col-sm-6">
                                    <label>Categoría</label>
                                    <select name="CAT_NOMBRE" class="js-example-basic-multiple sel_rep" id="categoria">
                                        <option value="-1">--Seleccione un Contenido--</option>
                                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($s->CAT_ID); ?>"><?php echo e($s->CAT_NOMBRE); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group col-sm-6">
                                    <label>Sección</label>
                                    <select name="SEC_NOMBRE" class="js-example-basic-multiple sel_rep" id="seccion">
                                        <option value="-1">--Seleccione un Contenido--</option>
                                        <?php $__currentLoopData = $secciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($s->SEC_ID); ?>"><?php echo e($s->SEC_NOMBRE); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-sm-6">
                                    <label>Autor</label>
                                    <select name="AUT_NOMBRE" class="js-example-basic-multiple sel_rep" id="autor">
                                        <option value="-1">--Seleccione un Contenido--</option>
                                        <?php $__currentLoopData = $autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($s->AUT_ID); ?>"><?php echo e($s->AUT_NOMBRE); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group col-sm-6">
                                    <label>Editorial</label>
                                    <select name="EDI_NOMBRE" class="js-example-basic-multiple sel_rep" id="editorial">
                                        <option value="-1">--Seleccione un Contenido--</option>
                                        <?php $__currentLoopData = $editoriales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($s->EDI_ID); ?>"><?php echo e($s->EDI_NOMBRE); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <?php $reporte = 'rep_'.$con.'/-1/-1/-1/-1'; ?>
                            <?php elseif($con=='reservas' or $con=='prestamos'): ?>
                            <div class="row">
                                <div class="col-sm-3 form-group">
                                    <label>Desde</label>
                                    <input type="date" name="desde" id="desde" class="form-control" onChange="reportes('<?php echo e($con); ?>')">
                                </div>
                                <div class="col-sm-3">
                                    <label>Hasta</label>
                                    <input type="date" name="hasta" id="hasta" class="form-control" onChange="reportes('<?php echo e($con); ?>')">
                                </div>
                                <div class="form-group col-sm-6">
                                    <label>Ejemplar</label>
                                    <select name="EJE_ID" id="ejemplar" class="js-example-basic-multiple sel_rep" required>
                                        <option value="-1">--Seleccione un Contenido--</option>
                                        <?php $__currentLoopData = $ejemplares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($e->EJE_ID); ?>"><?php echo e('Cod:'.$e->EJE_CODIGO.' - ISBN:'.$e->CON_ISBN.' - Titulo:'.$e->CON_TITULO.' - Autor:'.$e->AUT_NOMBRE); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-3 form-group">
                                    <label>Personal</label>
                                    <select name="personal" id="personal" class="js-example-basic-multiple sel_rep">
                                        <option value="-1">--Todos--</option>
                                        <?php $__currentLoopData = $personal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($e->PER_ID); ?>">Nombre: <?php echo e($e->PER_NOMBRES); ?> <?php echo e($e->PER_APELLIDOS); ?> - CI: <?php echo e($e->PER_CI); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-sm-3">
                                    <label>Lector</label>
                                    <select name="lector" id="lector" class="js-example-basic-multiple sel_rep">
                                        <option value="-1">--Todos--</option>
                                        <?php $__currentLoopData = $lectores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($e->LEC_ID); ?>">Nombre: <?php echo e($e->LEC_NOMBRES); ?> <?php echo e($e->LEC_APELLIDOS); ?> - CI: <?php echo e($e->LEC_CI); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-sm-3">
                                    <label>Estado</label>
                                    <select name="estado" id="estado" class="form-control" onChange="reportes('<?php echo e($con); ?>')">
                                        <option value="-1">--Todos--</option>
                                        <?php if($con=='reservas'): ?>
                                        <option value="1">Realizada</option>
                                        <option value="2">Concretada</option>
                                        <option value="3">Incumplida</option>
                                        <?php else: ?>
                                        <option value="1">Prestado</option>
                                        <option value="2">Devuelto</option>
                                        <option value="3">Devuelto a destiempo</option>
                                        <option value="4">No Devuelto</option>
                                        <?php endif; ?>
                                        <!--<option value="1">Reservado</option>
                                        <option value="2">Prestado</option>
                                        <option value="3">Devuelto</option>-->
                                    </select>
                                </div>
                                <div class="col-sm-3">
                                    <label>Tipo</label>
                                    <select name="estado" id="tipol" class="form-control" onChange="reportes('<?php echo e($con); ?>')">
                                        <option value="-1">--Todos--</option>
                                        <option value="1">Estudiante</option>
                                        <option value="2">Docente</option>
                                        <option value="3">Externo</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-sm-3">
                                    <label>Categoría</label>
                                    <select name="CAT_NOMBRE" id="categoria" class="js-example-basic-multiple sel_rep" required>
                                        <option value="-1">--Todos--</option>
                                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($s->CAT_ID); ?>"><?php echo e($s->CAT_NOMBRE); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group col-sm-3">
                                    <label>Sección</label>
                                    <select name="SEC_NOMBRE" id="seccion" class="js-example-basic-multiple sel_rep">
                                        <option value="-1">--Todos--</option>
                                        <?php $__currentLoopData = $secciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($s->SEC_ID); ?>"><?php echo e($s->SEC_NOMBRE); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group col-sm-3">
                                    <label>Autor</label>
                                    <select name="AUT_NOMBRE" id="autor" class="js-example-basic-multiple sel_rep" required>
                                        <option value="-1">--Todos--</option>
                                        <?php $__currentLoopData = $autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($s->AUT_ID); ?>"><?php echo e($s->AUT_NOMBRE); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group col-sm-3">
                                    <label>Editorial</label>
                                    <select name="EDI_NOMBRE" id="editorial" class="js-example-basic-multiple sel_rep">
                                        <option value="-1">--Todos--</option>
                                        <?php $__currentLoopData = $editoriales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($s->EDI_ID); ?>"><?php echo e($s->EDI_NOMBRE); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <?php $reporte = 'rep_'.$con.'/-1/-1/-1/-1/-1/-1/-1/-1/-1/-1/-1'; ?>
                            <?php endif; ?>
                            <input type="hidden" id="tipoc" value="<?php echo e($con); ?>">
                            <iframe id="some_id" class="some_pdf" src="<?php echo e(asset($reporte)); ?>" width="100%" height="620" scrollbar="yes" marginwidth="0" marginheight="0" hspace="0" align="middle" frameborder="0" scrolling="yes" style="width:100%; border:0; overflow:auto;" onload="resizeIframe(this)"></iframe>
                        </div>
                    </div>
                    <!-- END USER DATA-->
                </div>
                
            </div>
            
            
            <div class="row">
                <div class="col-md-12">
                    <div class="copyright">
                        <p>Copyright © 2022</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp8\htdocs\sis_biblioteca\resources\views/reportes/index.blade.php ENDPATH**/ ?>