<div class="row">
    <div class="col-md-12">
        <div class="copyright">
            <p>Copyright © 2022</p>
        </div>
    </div>
</div><?php /**PATH D:\xampp8\htdocs\sis_biblioteca\resources\views/partials/footer-cont.blade.php ENDPATH**/ ?>