<!--<div class="row">
    <div class="form-group col-sm-12">
        <label>Prestamo</label>
        <select name="PRE_ID" class="form-control PRE_ID" required>
            <?php $__currentLoopData = $prestamos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($p->PRE_ID); ?>"><?php echo e($p->PRE_ID); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>-->
<div class="row">
    <div class="form-group col-sm-6">
        <label>Fecha</label>
        <input type="date" name="DEV_FECHA" class="form-control DEV_FECHA" required value="<?php echo e(date('Y-m-d')); ?>">
    </div>
    <div class="form-group col-sm-6">
        <label>Hora</label>
        <input type="time" name="DEV_HORA" class="form-control DEV_HORA" required value="<?php echo e(date('H:i')); ?>">
    </div>
</div>
<div class="row">
    <div class="form-group col-sm-12">
        <label>Observaciones</label>
        <textarea type="text" name="DEV_OBS" class="form-control DEV_OBS" ></textarea>
    </div>
</div>
<input type="hidden" name="PRE_ID" class="form-control PRE_ID" required><?php /**PATH D:\xampp8\htdocs\sis_biblioteca\resources\views/devoluciones/form.blade.php ENDPATH**/ ?>