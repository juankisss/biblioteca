<div class="row">
    <div class="form-group col-sm-12">
        <label>Nombre</label>
        <input type="text" name="SEC_NOMBRE" class="form-control SEC_NOMBRE" required>
    </div>
</div>
<div class="row">
    <div class="form-group col-sm-12">
        <label>Descripción</label>
        <textarea type="text" name="SEC_DESC" class="form-control SEC_DESC"></textarea>
    </div>
</div>
<div class="row">
    <div class="form-group col-sm-12">
        <label>Referencia</label>
        <input type="text" name="SEC_REFERENCIA" class="form-control SEC_REFERENCIA">
    </div>
</div>