<div class="row">
    <div class="form-group col-sm-12">
        <label>Nombre</label>
        <input type="text" name="AUT_NOMBRE" class="form-control AUT_NOMBRE" required>
    </div>
    <!--<div class="form-group col-sm-6">
        <label>e-Mail</label>
        <input type="email" name="AUT_EMAIL" class="form-control AUT_EMAIL">
    </div>-->
</div>
<div class="row">
    <div class="form-group col-sm-6">
        <label>Fecha Nacimiento</label>
        <input type="date" name="AUT_FECHAN" class="form-control AUT_FECHAN">
    </div>
    <div class="form-group col-sm-6">
        <label>Lugar Nacimiento</label>
        <input type="text" name="AUT_LUGARN" class="form-control AUT_LUGARN">
    </div>
</div>
<!--<div class="row">
    <div class="form-group col-sm-12">
        <label>Biografía</label>
        <textarea type="text" name="AUT_BIOGRAFIA" class="form-control AUT_BIOGRAFIA"></textarea>
    </div>
</div>
<div class="row">
    <div class="form-group col-sm-12">
        <label>Imagen</label>
        <input type="file" name="file" class="form-control AUT_IMAGEN">
    </div>
</div>-->