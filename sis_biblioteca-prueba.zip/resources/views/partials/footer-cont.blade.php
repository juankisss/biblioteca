<div class="row">
    <div class="col-md-12">
        <div class="copyright">
            <p>Copyright © JC 2022</p>
        </div>
    </div>
</div>